<template>
  <transition name="modal">
    <div class="modal is-active">
      <div class="modal-background"></div>
      <div class="modal-card">
        <header class="modal-card-head">
          <p class="modal-card-title">
            Bulk Mail To Selective Cilents
            <slot name="header">
              <button
                class="delete closeButton"
                aria-label="close"
                @click="close"
              ></button>
            </slot>
          </p>
          <slot name="header-button"></slot>
        </header>
        <section class="modal-card-body">
          <md-card>
            <md-card-content>
              {{ id }}
             <div class="md-layout-item">
                <md-field>
                  <label>E_Mail Title</label>
                  <md-input v-model="header"></md-input>
                </md-field>
                <md-field>
                  <label>Content</label>
                  <md-textarea v-model="content"/>
                </md-field>
                <md-field>
                  <label>Footer</label>
                  <md-input v-model="footer"></md-input>
                  <span class="md-helper-text">Helper text</span>
                </md-field>
                <md-field>
                   <md-button class="md-primary" @click="sendMail">Mail</md-button>
                </md-field>
              </div>
            </md-card-content>
          </md-card>
        </section>
        <footer class="modal-card-foot">
          <slot name="footer"></slot>
        </footer>
      </div>
    </div>
  </transition>
</template>

<script>
export default {
  props: ["bulkmailid"],
  name: "CilentMail",
  created() {
    console.log(this.id);
  },
  data() {
    return {
      id: this.bulkmailid,
      header:"",
      content:"",
      footer:"",
    };
  },
  methods: {
    sendMail()
    {
     axios.post('/api/sendBulkMail',
     {
        cid:this.id,header:this.header,content:this.content,footer:this.footer
     }).then(response=>{
        console.log(response);
     }).catch(error=>{
       console.log(error);
     });
    },
    close() {
      this.$emit("close");
    },
  },
};
</script>
<style>
.closeButton {
  float: right;
}
</style>